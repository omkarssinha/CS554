const showData = require('./shows');
const searchData = require('./search');

module.exports = {
  shows: showData,
  search: searchData
};