const pokeData = require('./pokemon');

module.exports = {
  pokemon: pokeData
};