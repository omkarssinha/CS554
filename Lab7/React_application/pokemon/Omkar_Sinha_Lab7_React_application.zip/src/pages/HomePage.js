import React from 'react';
import Header from '../components/Header';

function HomePage() {
    return (
        <div>
            <Header text="PokemonAPI"/>
            <p><center>    Welcome to the PokemonAPI!!!<br/>
               This site is for you to view your favorite pokemon and catch them too!! You may also scroll down the list!</center></p>
        </div>
    )
}

export default HomePage
